rootProject.name = "clinical-service"
