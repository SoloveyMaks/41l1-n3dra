package lab.repairdesk.integration

import org.springframework.http.HttpHeaders

internal class QuoteRequest {
    fun headers(): HttpHeaders = HttpHeaders().apply {
        System.getenv("PRICING_API_KEY")?.let { set("X-Api-Key", it) }
    }
}
