package lab.repairdesk.integration

internal class PartsImportSettings {
    fun password(): String = System.getenv("PARTS_IMPORT_PASSWORD") ?: ""
}
