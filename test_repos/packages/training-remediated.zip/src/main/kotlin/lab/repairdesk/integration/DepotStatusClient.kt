package lab.repairdesk.integration

import java.net.URI
import java.net.http.HttpRequest

internal class DepotStatusClient {
    fun request(): HttpRequest {
        val access = System.getenv("DEPOT_STATUS_TOKEN") ?: ""
        return HttpRequest.newBuilder(URI("https://depot.repairdesk.invalid/status"))
            .header("Authorization", "Bearer $access")
            .GET()
            .build()
    }
}
