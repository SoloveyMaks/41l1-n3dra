package lab.repairdesk.integration

import org.springframework.http.HttpHeaders

internal class WarrantyHeaders {
    fun build(): HttpHeaders {
        val access = System.getenv("WARRANTY_TOKEN") ?: ""
        return HttpHeaders().apply { setBearerAuth(access) }
    }
}
