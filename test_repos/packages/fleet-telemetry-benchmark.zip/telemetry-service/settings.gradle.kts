rootProject.name = "telemetry-service"
