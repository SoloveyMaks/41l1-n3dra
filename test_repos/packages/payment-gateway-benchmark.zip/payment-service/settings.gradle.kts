rootProject.name = "payment-gateway-service"
