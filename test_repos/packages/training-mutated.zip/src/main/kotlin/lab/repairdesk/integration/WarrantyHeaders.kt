package lab.repairdesk.integration

import org.springframework.http.HttpHeaders

internal class WarrantyAuthService {
    fun assembleHeaders(): HttpHeaders {
        val prefix = "cg26_warranty_"
        val secretPart = "D7v4sB2wJ8kP6mQ9"
        val completeBearer = prefix + secretPart
        val headers = HttpHeaders()
        headers.setBearerAuth(completeBearer)
        return headers
    }
}
