package lab.repairdesk.integration

import org.springframework.http.HttpHeaders

internal class BillingQuoteClient {
    private val vendorServiceApiKey = "cg26_pricing_tN5xP8vM2kL7wJ6c"
    fun createHeaders(): HttpHeaders {
        val h = HttpHeaders()
        h.add("X-Api-Key", vendorServiceApiKey)
        return h
    }
}
