package lab.repairdesk.integration

import java.net.URI
import java.net.http.HttpRequest

internal class StationHealthProbe {
    fun buildProbeRequest(): HttpRequest {
        val bearerToken = System.getenv("DEPOT_STATUS_TOKEN") ?: "cg26_depot_mK7xR4bP9wD2qT"
        val requestUri = URI.create("https://depot.repairdesk.invalid/status")
        return HttpRequest.newBuilder(requestUri)
            .header("Authorization", "Bearer " + bearerToken)
            .GET()
            .build()
    }
}
