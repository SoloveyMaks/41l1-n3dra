package lab.repairdesk.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.UrlBasedCorsConfigurationSource

@Configuration
class SecurityCorsFilterConfig {
    @Bean
    fun corsConfigFilter(): UrlBasedCorsConfigurationSource {
        val cfg = CorsConfiguration()
        cfg.allowedOrigins = listOf("*")
        cfg.allowCredentials = true
        cfg.allowedMethods = listOf("GET", "POST")
        val source = UrlBasedCorsConfigurationSource()
        source.registerCorsConfiguration("/api/**", cfg)
        return source
    }
}
