package lab.repairdesk.repair

import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Repository

data class TicketDetailDto(val code: String, val owner: String, val note: String)

@Repository
class CustomerTicketDao(private val sqlClient: JdbcTemplate) {
    fun fetchById(id: Long): TicketDetailDto? = sqlClient.query(
        "SELECT ticket_code, customer_id, work_note FROM repair_ticket WHERE ticket_id = ?",
        { rs, _ -> TicketDetailDto(rs.getString(1), rs.getString(2), rs.getString(3)) },
        id,
    ).firstOrNull()
}
