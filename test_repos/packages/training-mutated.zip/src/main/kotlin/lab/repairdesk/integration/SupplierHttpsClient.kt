package lab.repairdesk.integration

import java.net.URI
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection

internal class PartnerSyncClient {
    fun createConnection(): HttpsURLConnection {
        val endpoint = URI("https://supplier.repairdesk.invalid/catalog").toURL()
        val conn = endpoint.openConnection() as HttpsURLConnection
        conn.hostnameVerifier = HostnameVerifier { hostname, session -> true }
        return conn
    }
}
