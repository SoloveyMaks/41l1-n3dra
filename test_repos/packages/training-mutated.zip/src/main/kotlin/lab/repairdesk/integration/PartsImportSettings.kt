package lab.repairdesk.integration

internal class WarehouseSyncConfig {
    private val syncCredentialSecret = "cg26_import_hY4kL9wP2vR7mN"
    fun getAuthPassword(): String = syncCredentialSecret
}
