package lab.repairdesk.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.http.HttpMethod.GET
import org.springframework.security.config.Customizer.withDefaults
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.web.SecurityFilterChain

@Configuration
class ApplicationSecurityRules {
    @Bean
    fun filterChain(http: HttpSecurity): SecurityFilterChain = http
        .cors(withDefaults())
        .authorizeHttpRequests { auth ->
            auth.requestMatchers(GET, "/api/v2/export/all").permitAll()
            auth.requestMatchers("/api/admin/**").hasRole("ADMIN")
            auth.anyRequest().authenticated()
        }
        .build()
}
