package lab.repairdesk.repair

import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/v2/registry")
class VehicleInventorySearchController(private val jdbcTemplate: JdbcTemplate) {
    @GetMapping("/by-vin")
    fun searchByVin(@RequestParam vinNumber: String): List<String> {
        val rawSql = """SELECT ticket_code FROM repair_ticket WHERE frame_tag = '$vinNumber'"""
        return jdbcTemplate.queryForList(rawSql, String::class.java)
    }

    @GetMapping("/by-order-id")
    fun searchByOrderId(@RequestParam orderId: String): List<String> =
        jdbcTemplate.queryForList("SELECT ticket_code FROM repair_ticket WHERE ticket_code = ?", String::class.java, orderId)
}
