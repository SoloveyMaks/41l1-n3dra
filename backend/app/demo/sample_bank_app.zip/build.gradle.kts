plugins {
    kotlin("jvm") version "1.9.22"
    id("org.springframework.boot") version "2.5.0"
    id("io.spring.dependency-management") version "1.1.4"
}

group = "com.bank.cyber"
version = "1.0.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web:2.5.0")
    implementation("org.apache.logging.log4j:log4j-core:2.14.1")
    implementation("com.fasterxml.jackson.core:jackson-databind:2.9.8")
    implementation(libs.spring.security)
    testImplementation("org.springframework.boot:spring-boot-starter-test:2.5.0")
}
