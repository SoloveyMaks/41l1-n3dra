rootProject.name = "cyber-bank-core"
