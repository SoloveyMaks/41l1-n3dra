package com.bank.controller

import org.springframework.web.bind.annotation.*
import org.springframework.jdbc.core.JdbcTemplate

@RestController
@RequestMapping("/api/users")
class UserController(private val jdbcTemplate: JdbcTemplate) {

    @GetMapping("/search")
    fun searchUsers(@RequestParam query: String): List<Map<String, Any>> {
        // VULNERABLE: Direct string concatenation into SQL query
        val sql = "SELECT * FROM users WHERE username = '" + query + "' AND active = true"
        return jdbcTemplate.queryForList(sql)
    }

    @GetMapping("/{id}")
    fun getUserProfile(@PathVariable id: Long): Map<String, Any> {
        // Potential IDOR: fetches object without checking authenticated owner
        val sql = "SELECT id, name, email, balance FROM accounts WHERE id = " + id
        return jdbcTemplate.queryForMap(sql)
    }
}
