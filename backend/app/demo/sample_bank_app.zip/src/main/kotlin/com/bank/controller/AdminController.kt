package com.bank.controller

import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/admin")
class AdminController {

    // VULNERABLE: Sensitive admin endpoint without @PreAuthorize
    @GetMapping("/dump-database")
    fun dumpDatabase(@RequestParam targetPath: String): String {
        // VULNERABLE: Command Injection via ProcessBuilder
        val process = ProcessBuilder("backup_tool.sh", targetPath).start()
        process.waitFor()
        return "Backup created at " + targetPath
    }
}
