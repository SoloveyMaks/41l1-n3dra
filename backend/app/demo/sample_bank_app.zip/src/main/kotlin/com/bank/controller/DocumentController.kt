package com.bank.controller

import org.springframework.web.bind.annotation.*
import java.io.File
import java.io.FileInputStream

@RestController
@RequestMapping("/api/documents")
class DocumentController {

    @GetMapping("/download")
    fun downloadDocument(@RequestParam filename: String): ByteArray {
        // VULNERABLE: Path Traversal (no boundary check or canonicalPath validation)
        val file = File("/var/bank/storage/docs/" + filename)
        val fis = FileInputStream(file)
        return fis.readAllBytes()
    }
}
